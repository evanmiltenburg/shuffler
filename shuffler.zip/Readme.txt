Shuffler is a cute python script if that makes any sense at all!

Make sure that shuffler.py and mydict.txt are in the same folder.

Enjoy!